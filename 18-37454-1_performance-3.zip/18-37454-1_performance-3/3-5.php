<html>
<body>

<form action="welcome.php" method="post">
	Degree<br>
<input type="checkbox" name="degree1" value="SSC">SSC 
  <input type="checkbox" name="degree2" value="HSC">HSC 
  <input type="checkbox" name="degree3" value="BSc">BSc 
  <input type="checkbox" name="degree4" value="MSc">MSc<br>

<input type="submit">
</form>

</body>
</html>