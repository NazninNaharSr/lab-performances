<html>
<body>

<form action="welcome.php" method="post">
Name <br>
<input type="text" name="name"><br>

<input type="submit">
</form>

</body>
</html>