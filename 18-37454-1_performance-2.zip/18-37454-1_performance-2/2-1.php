<?php  
 $length = 14;  
 $width = 12;  
 echo "area of rectangle is $length * $width= " . ($length * $width) . "<br />"; 
  echo "perimeter of rectangle is $length * $width= " . (2($length + $width)) . "<br />"; 
  ?> 

